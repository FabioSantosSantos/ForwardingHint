# Forwarding-Hint with NLSR / LSDB route disambiguation

Branch: `feature/forwarding-hint-nlsr`

## Goal

Keep the generic Forwarding-Hint idea, but use NLSR's link-state information to disambiguate equal-cost or otherwise ambiguous next hops. The Interest carries a compact `ID_Route`; it does **not** carry the complete path sequence.

## Interest hint format

The branch accepts the following NDN Name in the ForwardingHint field:

- Legacy: `<cost>` — preserves the original cost-only behavior.
- NLSR: `<cost>/<ID_Route>` — route ID is the second numeric component and remains unchanged across hops.

The strategy first considers only next hops matching the hinted cost and excludes the ingress face. If exactly one eligible next hop matches, it forwards directly without consulting `ID_Route`. Only when multiple eligible next hops have the same hinted cost does it consult the local catalog for `(FIB destination prefix, ID_Route)` and select the mapped face, provided that face is among those equal-cost candidates. If the ID is absent, unknown, stale, or maps outside the candidate set, it retains the legacy first-match behavior rather than silently dropping the Interest. The route ID is preserved in the outgoing hint so downstream routers can resolve their own ambiguities.

## NLSR/LSDB integration contract

NLSR runs as a separate routing daemon from NFD. The strategy therefore cannot read NLSR's in-memory LSDB directly. `nlsr-route-catalog.hpp/.cpp` provides the local interface that an NLSR integration adapter must populate:

```cpp
NlsrRouteCatalog::getInstance().upsert(destinationPrefix, routeId, localFaceId);
NlsrRouteCatalog::getInstance().erase(destinationPrefix, routeId);
```

The adapter must:

1. Read the local NLSR LSDB, including Name LSA and Adjacency LSA information.
2. Derive a stable `ID_Route` for each route/path candidate using a deterministic path enumeration/canonicalization rule shared by all routers.
3. At each router, map `(destination prefix, ID_Route)` to the local outgoing NFD FaceId that is the next hop on that path.
4. Update/remove entries when LSAs, routes, or faces change.
5. Ensure the Interest origin inserts the same `ID_Route` in the ForwardingHint.

**Important limitation:** the uploaded repository contains only the NFD forwarding strategy and an NDVRv2 archive; it does not contain NLSR source or an LSDB-to-NFD integration mechanism. This branch adds the strategy-side route-ID handling and catalog API, but it is not an end-to-end NLSR integration until that adapter is implemented and wired into the actual NLSR/NFD build. The catalog must also be compiled into NFD.

## Build integration

Add `nlsr-route-catalog.cpp` to the NFD target that already compiles `forwarding-hint-strategy.cpp`, and install/include `nlsr-route-catalog.hpp`. Exact build-file edits depend on the NFD version/build system, which is not included in the uploaded archive.

## Validation checklist

- A cost-only hint continues to use the legacy behavior.
- A unique matching cost forwards without consulting the route catalog, even if `ID_Route` is present.
- Multiple matching next hops consult `ID_Route` and select the mapped face only if it is one of the equal-cost candidates.
- Two equal-cost paths with different IDs select different local next hops.
- An unknown/stale route ID falls back to cost-only behavior.
- LSDB changes refresh the catalog and prevent stale FaceIds from persisting.
- Test path changes, link failures, loops, and Interest aggregation/PIT behavior in MiniNDN before performance evaluation.
