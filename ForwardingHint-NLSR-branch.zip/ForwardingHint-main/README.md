# Forwarding-Hint for Named Data Networking

Forwarding-Hint is an NDN forwarding strategy that uses compact path guidance in Interest packets to disambiguate forwarding choices.

## Variants in this repository

- **Cost-only baseline:** legacy behavior using the first ForwardingHint component.
- **NLSR route-ID branch:** see [`README-NLSR.md`](README-NLSR.md). The NLSR variant uses `cost/ID_Route` and a local route catalog intended to be populated from NLSR Name LSA and Adjacency LSA / LSDB information. The strategy consults `ID_Route` only when multiple eligible next hops match the hinted cost; a unique match is forwarded directly.

The NLSR branch includes the strategy-side route-ID handling and the catalog API. Because the supplied archive does not include NLSR source or an LSDB integration adapter, the adapter and build-system wiring remain necessary before it can be considered an end-to-end working NLSR implementation.
