#include "forwarding-hint-strategy.hpp"

#include "fw/forwarder.hpp"
#include "table/fib.hpp"
#include "nlsr-route-catalog.hpp"
#include "core/logger.hpp"

namespace nfd {
namespace fw {

NFD_LOG_INIT(ForwardingHintStrategy);

//const ndn::Name STRATEGY_NAME("/localhost/nfd/strategy/forwarding-hint");

NFD_REGISTER_STRATEGY(ForwardingHintStrategy);

//const ndn::Name&
//ForwardingHintStrategy::getStrategyName()
//{
//  return STRATEGY_NAME;
//}
const ndn::Name&
ForwardingHintStrategy::getStrategyName()
{
  static const auto strategyName = Name("/localhost/nfd/strategy/forwarding-hint").appendVersion(1);
  return strategyName;
}



ForwardingHintStrategy::ForwardingHintStrategy(Forwarder& forwarder,
                                               const ndn::Name& name)
  : Strategy(forwarder)
{
  this->setInstanceName(name);
}


void
ForwardingHintStrategy::afterReceiveInterest(const Interest& interest,
                                             const FaceEndpoint& ingress,
                                             const shared_ptr<pit::Entry>& pitEntry)
{
  // Preserve the original behavior when there is no previous-hop hint.
  if (pitEntry->getOutRecords().empty()) {
    forwardFirstHop(interest, ingress, pitEntry);
    return;
  }

  // ID_Route is intentionally consulted only if multiple eligible next hops
  // have the same hinted cost. A unique cost match is sufficient by itself.
  forwardWithHint(interest, ingress, pitEntry);
}

bool
ForwardingHintStrategy::extractRouteId(const Interest& interest, uint64_t& routeId) const
{
  auto fh = interest.getForwardingHint();
  if (fh.empty() || fh.front().size() < 2)
    return false;

  try {
    routeId = fh.front().at(1).toNumber();
    return true;
  }
  catch (...) {
    return false;
  }
}


void
ForwardingHintStrategy::forwardFirstHop(const Interest& interest,
                                        const FaceEndpoint& ingress,
                                        const shared_ptr<pit::Entry>& pitEntry)
{
  const fib::Entry& fibEntry = this->lookupFib(*pitEntry);

  for (const auto& nh : fibEntry.getNextHops()) {
    if (nh.getFace().getId() == ingress.face.getId())
      continue;

    int newCost = static_cast<int>(nh.getCost()) - 1;

    Interest outInterest = makeUpdatedInterest(interest, newCost);
    this->sendInterest(outInterest, nh.getFace(), pitEntry);
  }
}

void
ForwardingHintStrategy::forwardWithHint(const Interest& interest,
                                        const FaceEndpoint& ingress,
                                        const shared_ptr<pit::Entry>& pitEntry)
{
  const int cost = extractHintValue(interest);
  if (cost < 0) {
    forwardFirstHop(interest, ingress, pitEntry);
    return;
  }

  const fib::Entry& fibEntry = this->lookupFib(*pitEntry);
  const fib::NextHop* firstCandidate = nullptr;
  const fib::NextHop* uniqueCandidate = nullptr;
  size_t candidateCount = 0;

  for (const auto& nh : fibEntry.getNextHops()) {
    if (static_cast<int>(nh.getCost()) != cost ||
        nh.getFace().getId() == ingress.face.getId()) {
      continue;
    }

    if (firstCandidate == nullptr)
      firstCandidate = &nh;
    uniqueCandidate = &nh;
    ++candidateCount;
  }

  if (candidateCount == 0) {
    forwardFirstHop(interest, ingress, pitEntry);
    return;
  }

  const fib::NextHop* selected = nullptr;
  if (candidateCount == 1) {
    // No ambiguity: do not parse or consult ID_Route.
    selected = uniqueCandidate;
  }
  else {
    // Ambiguous cost: use ID_Route, if present, to disambiguate the face.
    uint64_t routeId = 0;
    uint64_t faceId = 0;
    if (extractRouteId(interest, routeId) &&
        NlsrRouteCatalog::getInstance().findFaceId(fibEntry.getPrefix(), routeId, faceId)) {
      for (const auto& nh : fibEntry.getNextHops()) {
        if (static_cast<int>(nh.getCost()) == cost &&
            nh.getFace().getId() != ingress.face.getId() &&
            nh.getFace().getId() == faceId) {
          selected = &nh;
          break;
        }
      }
    }

    // Unknown/stale ID_Route: retain the legacy first-match behavior.
    if (selected == nullptr)
      selected = firstCandidate;
  }

  Interest outInterest = makeUpdatedInterest(interest, cost - 1);
  this->sendInterest(outInterest, selected->getFace(), pitEntry);
}

int
ForwardingHintStrategy::extractHintValue(const Interest& interest) const
{
  auto fh = interest.getForwardingHint();
  if (fh.empty())
    return -1;

  try {
    return static_cast<int>(fh.front().at(0).toNumber());
  }
  catch (...) {
    return -1;
  }
}

Interest
ForwardingHintStrategy::makeUpdatedInterest(const Interest& original,
                                            int newCost) const
{
  Interest interest(original);

  uint64_t routeId = 0;
  const bool hasRouteId = extractRouteId(original, routeId);

  if (newCost < 0 && !hasRouteId) {
    interest.setForwardingHint({});
    return interest;
  }

  ndn::Name hint;
  hint.appendNumber(newCost < 0 ? 0 : static_cast<uint64_t>(newCost));
  if (hasRouteId)
    hint.appendNumber(routeId);

  interest.setForwardingHint({hint});
  return interest;
}

} // namespace fw
} // namespace nfd
