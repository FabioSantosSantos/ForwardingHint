#include "nlsr-route-catalog.hpp"

namespace nfd {
namespace fw {

NlsrRouteCatalog&
NlsrRouteCatalog::getInstance()
{
  static NlsrRouteCatalog catalog;
  return catalog;
}

void
NlsrRouteCatalog::upsert(const ndn::Name& destination, uint64_t routeId, uint64_t faceId)
{
  std::lock_guard<std::mutex> lock(m_mutex);
  m_routes[Key(destination, routeId)] = faceId;
}

void
NlsrRouteCatalog::erase(const ndn::Name& destination, uint64_t routeId)
{
  std::lock_guard<std::mutex> lock(m_mutex);
  m_routes.erase(Key(destination, routeId));
}

void
NlsrRouteCatalog::clear()
{
  std::lock_guard<std::mutex> lock(m_mutex);
  m_routes.clear();
}

bool
NlsrRouteCatalog::findFaceId(const ndn::Name& destination, uint64_t routeId,
                             uint64_t& faceId) const
{
  std::lock_guard<std::mutex> lock(m_mutex);
  auto it = m_routes.find(Key(destination, routeId));
  if (it == m_routes.end())
    return false;
  faceId = it->second;
  return true;
}

} // namespace fw
} // namespace nfd
