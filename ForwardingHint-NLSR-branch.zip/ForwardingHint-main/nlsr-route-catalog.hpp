#ifndef NFD_DAEMON_FW_NLSR_ROUTE_CATALOG_HPP
#define NFD_DAEMON_FW_NLSR_ROUTE_CATALOG_HPP

#include "common.hpp"
#include <map>
#include <mutex>
#include <utility>

namespace nfd {
namespace fw {

/**
 * Local forwarding view built by an NLSR/LSDB integration adapter.
 *
 * Each router stores (destination prefix, ID_Route) -> local outgoing FaceId.
 * ID_Route is a stable identifier for a path derived from the same NLSR LSDB
 * view at every router. The Interest carries only this identifier, not the
 * complete router sequence.
 *
 * This catalog deliberately does not parse NLSR LSAs: NLSR runs as a separate
 * routing daemon, so a deployment must feed this table from its NLSR LSDB and
 * keep entries synchronized with topology and face changes.
 */
class NlsrRouteCatalog
{
public:
  static NlsrRouteCatalog&
  getInstance();

  void
  upsert(const ndn::Name& destination, uint64_t routeId, uint64_t faceId);

  void
  erase(const ndn::Name& destination, uint64_t routeId);

  void
  clear();

  bool
  findFaceId(const ndn::Name& destination, uint64_t routeId, uint64_t& faceId) const;

private:
  using Key = std::pair<ndn::Name, uint64_t>;
  mutable std::mutex m_mutex;
  std::map<Key, uint64_t> m_routes;
};

} // namespace fw
} // namespace nfd

#endif // NFD_DAEMON_FW_NLSR_ROUTE_CATALOG_HPP
