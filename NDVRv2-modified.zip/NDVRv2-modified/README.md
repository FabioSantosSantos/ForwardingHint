# NDVRv2 modifications for Forwarding Hint ID_Route

The two modified headers expose the probabilistic IBF route vector selected by
NDVRv2:

- `NextHopIBFBased::getIdRoute()` serializes the current IBF vector.
- `PathVectorsIBFBased::getBestIdRoute(faceId, idRoute)` returns the vector
  associated with the lowest-cost path on a face.
- `RoutingEntry::GetBestIdRoute(faceId, idRoute)` exposes the same information
  to an integration layer.

Apply the integration described in the Forwarding Hint project README so the
forwarding strategy receives the vector and the next-router identifier.
