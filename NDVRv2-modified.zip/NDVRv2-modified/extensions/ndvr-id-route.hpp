#ifndef NDVR_ID_ROUTE_HPP
#define NDVR_ID_ROUTE_HPP

#include <cstdint>
#include <functional>
#include <string>
#include <unordered_map>

namespace nfd::fw {

/**
 * Integration boundary between NDVRv2 and the forwarding strategy.
 *
 * NDVRv2 provides, for each destination prefix and outgoing face:
 *   - the probabilistic route vector selected for that path (ID_Route);
 *   - the router identifier of the immediate neighbor on that face.
 *
 * The forwarding strategy uses ID_Route only when the Forwarding Hint cost
 * produces more than one candidate interface.
 */
class NdvrIdRouteRegistry
{
public:
  struct RouteInfo
  {
    uint64_t idRoute = 0;
    std::string nextRouterId;
  };

  static NdvrIdRouteRegistry&
  get()
  {
    static NdvrIdRouteRegistry instance;
    return instance;
  }

  void
  set(const std::string& prefix, uint64_t faceId, uint64_t idRoute,
      const std::string& nextRouterId)
  {
    m_routes[makeKey(prefix, faceId)] = RouteInfo{idRoute, nextRouterId};
  }

  void
  erase(const std::string& prefix, uint64_t faceId)
  {
    m_routes.erase(makeKey(prefix, faceId));
  }

  bool
  get(const std::string& prefix, uint64_t faceId, RouteInfo& info) const
  {
    auto it = m_routes.find(makeKey(prefix, faceId));
    if (it == m_routes.end())
      return false;

    info = it->second;
    return true;
  }

  /**
   * Test membership using the same hashing rule as the current
   * SingleNumberIndexer implementation in NDVR+IBF.
   *
   * Bits [0,4] encode the count. Bits [5,63] are the probabilistic vector.
   */
  static bool
  contains(uint64_t idRoute, const std::string& routerId)
  {
    constexpr int HASH_FUNCTIONS = 3;
    constexpr int COUNTER_BITS = 5;
    constexpr int REAL_SIZE = 64 - COUNTER_BITS;

    for (int i = 0; i < HASH_FUNCTIONS; ++i) {
      const auto h = std::hash<std::string>{}(routerId + std::to_string(i));
      const int bit = static_cast<int>(h % REAL_SIZE) + COUNTER_BITS;
      if ((idRoute & (uint64_t{1} << bit)) == 0)
        return false;
    }

    return true;
  }

private:
  static std::string
  makeKey(const std::string& prefix, uint64_t faceId)
  {
    return prefix + "|" + std::to_string(faceId);
  }

private:
  std::unordered_map<std::string, RouteInfo> m_routes;
};

} // namespace nfd::fw

#endif // NDVR_ID_ROUTE_HPP
